/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listas.de.tarefas;

import br.com.tarefas.view.InicioPrograma;

/**
 *
 * @author Adm
 */
public class ProgramaListaTarefa {

    public static void main(String[] args) {
        InicioPrograma inicio = new InicioPrograma();
        inicio.mensagemBoasVindas();
        
    }
}
