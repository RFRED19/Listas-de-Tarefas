/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.tarefas.model;

/**
 *
 * @author Adm
 */
public class Tarefa {
    private Integer id;
    private String descricao;
    private Status status; 
    private Integer percentual; 
    private Pessoa pessoaPrestadorResponsavel;
    private Pessoa pessoRequisitante;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Integer getPercentual() {
        return percentual;
    }

    public void setPercentual(Integer percentual) {
        this.percentual = percentual;
    }

    public Pessoa getPessoaPrestador() {
        return pessoaPrestadorResponsavel;
    }

    public void setPessoaPrestador(Pessoa pessoaPrestador) {
        this.pessoaPrestadorResponsavel = pessoaPrestador;
    }

    public Pessoa getPessoRequisitante() {
        return pessoRequisitante;
    }

    public void setPessoRequisitante(Pessoa pessoRequisitante) {
        this.pessoRequisitante = pessoRequisitante;
    }
    
    
}
