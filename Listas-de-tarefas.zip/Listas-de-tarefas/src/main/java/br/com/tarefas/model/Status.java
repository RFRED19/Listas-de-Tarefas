/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.tarefas.model;

/**
 *
 * @author Adm
 */
public class Status {
    private Integer id;
    private String descricao; //Pendente, Andamento, Concluida, Pausado.
    
    public void setId(Integer id){
        this.id = id;
    }
    
    public Integer getId() {
        return this.id;
    }
    
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }
    
    public String getDescricao() {
        return this.descricao;
    }
}
