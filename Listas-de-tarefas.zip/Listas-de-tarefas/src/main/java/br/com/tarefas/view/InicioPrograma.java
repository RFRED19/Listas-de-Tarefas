/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.tarefas.view;

/**
 *
 * @author Adm
 */
public class InicioPrograma {
    public void mensagemBoasVindas(){
        String mensagem = "ola, seja bem vindo ao programa"
                + "Trabalha ou Vaza! <>Esteja Atualizado<>!";
        
        System.out.println(mensagem);
    }
    
}
