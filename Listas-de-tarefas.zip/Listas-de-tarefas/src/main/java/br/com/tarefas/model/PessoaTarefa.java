/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.tarefas.model;

/**
 *
 * @author Adm
 */
public class PessoaTarefa {
    private Integer id;
    private Tarefa tarefa;
    private Pessoa pessoaPrestador;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Tarefa getTarefa() {
        return tarefa;
    }

    public void setTarefa(Tarefa tarefa) {
        this.tarefa = tarefa;
    }

    public Pessoa getPessoaPrestador() {
        return pessoaPrestador;
    }

    public void setPessoaPrestador(Pessoa pessoaPrestador) {
        this.pessoaPrestador = pessoaPrestador;
    }
    
    
    
}
